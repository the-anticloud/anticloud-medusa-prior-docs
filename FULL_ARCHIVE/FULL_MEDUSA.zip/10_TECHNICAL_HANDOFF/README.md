# 10 Technical Handoff

**Project:** MEDUSA
**Upstream:** https://github.com/medusajs/medusa

Content specific to MEDUSA in category CLOTHING_RETAIL.
